@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion
title EXE Analyzer + Decompiler
cd /d "%~dp0"

rem === Path to Ghidra (for C/C++/Go/Rust). Leave empty if Ghidra is in the tools folder ===
set "GHIDRA_DIR="

rem --- Python check ---
where python >nul 2>nul
if errorlevel 1 (
    echo [!] Python not found. Install it from https://www.python.org ^(enable "Add to PATH"^).
    pause & exit /b 1
)
python -c "import pefile" 2>nul || (
    echo [*] Installing pefile...
    python -m pip install --quiet pefile
)

rem --- File: dragged onto the bat or asked for ---
set "EXE=%~1"
if "%EXE%"=="" (
    echo Drag an .exe file onto run.bat or enter its path:
    set /p "EXE=> "
)
set "EXE=%EXE:"=%"
if not exist "%EXE%" (
    echo [!] File not found: %EXE%
    pause & exit /b 1
)

echo.
echo ========== STEP 1: WHAT IS IT WRITTEN IN ==========
python "%~dp0analyze.py" "%EXE%"
echo.
choice /c YN /m "Decompile everything into folders"
if errorlevel 2 exit /b 0

echo.
echo ========== STEP 2: DECOMPILATION ==========
if defined GHIDRA_DIR (
    python "%~dp0exe_unpack.py" "%EXE%" --ghidra "%GHIDRA_DIR%"
) else (
    python "%~dp0exe_unpack.py" "%EXE%"
)

for %%F in ("%EXE%") do set "OUT=%%~dpnF_decompiled"
if exist "%OUT%" start "" explorer "%OUT%"
echo.
pause
